var admin;
var name;
name = "Василий";
admin = name;
alert('hi, ' + admin); 

var Tc = +prompt('температура по Цельсию: ');
var Tf= (9 / 5) * Tc + 32
 alert ('температура по Фаренгейту: ' + Tf);

var  JS = 1000 + "108"
alert (JS);